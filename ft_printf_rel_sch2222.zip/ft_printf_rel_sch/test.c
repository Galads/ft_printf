#include <stdio.h>
#include <stdlib.h>

int main ()
{
	char *str;
//	printf ("%");
	
	str = "0x";
//	free(str);
//	printf("|%d|\n", printf("|%.*D|\n", -10, 0));
	printf("%010s is a string", "this");
//	printf("%.*s", -3, 0);
	printf("%jd", 9223372036854775807);
	printf("%");
}
